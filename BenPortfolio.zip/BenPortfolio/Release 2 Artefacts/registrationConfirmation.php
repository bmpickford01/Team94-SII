<?php
echo "Registration confirmation";
?>
