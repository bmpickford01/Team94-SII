<?php
function db_connect() {
    try {
        // scheme name : test_wifi, account : kh273, password : password1!
        $pdo = new PDO('mysql:host=localhost;dbname=test_wifi', 'kh273', 'password1!');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (Exception $e) {
        echo $e->getMessage();
    }
}
?>
