<?php
include 'db_connect.php';

function specialCharCheck($str1) {

    if (substr_count($str1, '<') > 0 || substr_count($str1, '>') > 0) {
        echo "<script>alert('\'<\' and \'>\' cannot be used');";
        echo "history.back();</script>";
        return 0;
    }

}

if (isset($_POST['registerForm'])) { // when submitted registration form
    require './inc/validate.inc';

    // variables to store the result of validation
    $isName = false;
    $isEmail = false;
    $isPW = false;
    $isType = false;
    $isbirthday = false;
    $isPhoneNum = false;

    $errors = array();

    specialCharCheck($_POST['firstname']);
    specialCharCheck($_POST['lastname']);

    validateName($errors, $_POST, 'firstname', 'lastname');
    if ($errors) {
        $isName = false;
//        echo 'Errors:<br/>';
        foreach ($errors as $field => $error) {
            echo "$$error</br>";
        }
    } else { // valid. set flag variable as true
//        echo 'ID OK!<br>';
        $isName = true;
    }
    $errors = array();

    specialCharCheck($_POST['email']);

    validateEmail($errors, $_POST, 'email');
    if ($errors) {
        $isEmail = false;
//        echo 'Errors:<br/>';
        foreach ($errors as $field => $error) {
            echo "<script>alert('Notice\\r\\n\\r\\nEmail is invalid');";
            echo "history.back();</script>";
        }
    } else { // valid. set flag variable as true
//        echo 'email OK!<br>';
        $isEmail = true;
    }
    $errors = array();

    specialCharCheck($_POST['password']);
    specialCharCheck($_POST['passwordConfirm']);

    validPassword($errors, $_POST, 'password', 'passwordConfirm');
    if ($errors) {
//        echo 'Errors:<br/>';
        foreach ($errors as $field => $error) {

            echo "<script>alert('Notice\\r\\n\\r\\nPlease check password');";
            echo "history.back();</script>";

//            echo "$field $error</br>";
        }
        $isPW = false;
    } else { // valid. set flag variable as true
//        echo "pass OK<br>";
//        echo $_POST['email'] . "<br>";
//        echo $_POST['password'] . "<br>";
//        echo "hash: " . uniqid() . "<br>";
//        echo "call check password<br>";
        $isPW = true;
    }
    $errors = array();

    specialCharCheck($_POST['type']);
    validType($errors, $_POST, 'type');
    if ($errors) {
        $isType = false;
//        echo 'Errors:<br/>';
        foreach ($errors as $field => $error) {
            echo "<script>alert('Notice\\r\\n\\r\\nType is invalid');";
            echo "history.back();</script>";
//            echo "$error</br>";
        }
    } else { // valid. set flag variable as true
//        echo 'type OK!<br>';
        $isType = true;
    }
    $errors = array();

    specialCharCheck($_POST['birthDate']);
    specialCharCheck($_POST['birthMonth']);
    specialCharCheck($_POST['birthYear']);

    validBirthday($errors, $_POST, 'birthDate', 'birthMonth', 'birthYear');
    if ($errors) {
        $isbirthday = false;
//        echo 'Errors:<br/>';
        foreach ($errors as $field => $error) {
            echo "<script>alert('Notice\\r\\n\\r\\nBirthday is invalid\\r\\n".$_POST['birthDate']."/".$_POST['birthMonth']."/".$_POST['birthYear']."');";
            echo "history.back();</script>";
        }
    } else { // valid. set flag variable as true
//        echo 'ID OK!<br>';
        $isbirthday = true;
    }
    $errors = array();

    specialCharCheck($_POST['phoneNum1']);
    specialCharCheck($_POST['phoneNum2']);
    specialCharCheck($_POST['phoneNum3']);

    validPhoneNum($errors, $_POST, 'phoneNum1', 'phoneNum2', 'phoneNum3');
    if ($errors) {
        $isPhoneNum = false;
//        echo 'Errors:<br/>';
        foreach ($errors as $field => $error) {
            echo "<script>alert('Notice\\r\\n\\r\\nPhone number is invalid');";
            echo "history.back();</script>";
//            echo "$field $error</br>";
        }
    } else { // valid. set flag variable as true
//        echo 'ID OK!<br>';
        $isPhoneNum = true;
    }

    // call email existing check function when only all variables are valid
    if ($isName && $isEmail && $isPW && $isType && $isbirthday && $isPhoneNum) {

        // call insert function when only all variables are valid and email is not exists in database
        if (idExistCheck()) {
            insertMember();
        }

        else {
            echo "<script>alert('This email exist already.\\r\\nPlease go back and try again with other email.')</script>";
//            echo "Please go back and try again with other email";

        }

    }
    else {
//        echo "something wrong<br>";
    }
}

function idExistCheck() { // When email is not exits in database, return true, if not, return false
    try {
        require_once 'db_connect.php';
        $pdo = db_connect();

        // $stmt = $pdo->prepare('SELECT * FROM test_wifi.members WHERE members.email = :email and password = SHA2(CONCAT(:password, salt), 0)');
        $stmt = $pdo->prepare('SELECT * FROM  test_wifi.members WHERE members.email = :email');
        $stmt->bindParam(':email', $_POST['email'], PDO::PARAM_STR);
        //$email = $_POST['email'];
        $stmt->execute();

        if ($stmt->rowCount() > 0) { // the email exists. return false
//            echo "This email exists<br>";
            return false;
        }

        else { // the email is not in database. return true
//            echo "This email can be used<br>";
            return true;
        }

    } catch (PDOException $e) {
        echo "error error error" . "<br>";
        echo $e->getMessage();
    }
}

function insertMember() { // insert information of new user
    try {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $email = $_POST['email'];
        $password = $_POST['password'];
        $type = $_POST['type'];
        $birthDay = $_POST['birthDate'] . "-" . $_POST['birthMonth'] . "-" . $_POST['birthYear'];
        $phoneNum = $_POST['phoneNum1'] . "-" . $_POST['phoneNum2'] . "-" . $_POST['phoneNum3'];

//        echo "first: " . $firstname . "<br>";
//        echo "last: " . $lastname . "<br>";
//        echo "email: " . $email . "<br>";
//        echo "pass: " . $password . "<br>";
//        echo "type: " . $type . "<br>";
//        echo "birthday: " . $birthDay . "<br>";
//        echo "phone: " . $phoneNum . "<br><br>";

        // get date of today to store registration date in database
        date_default_timezone_set('Australia/Brisbane');
        $today = date('Y-m-d');

        // generate unique string to use as a slat
        $uniqid = uniqid();

//        echo "hash: " . $uniqid . "<br>";

        $pdo = db_connect();
//        $stmt = $pdo->prepare('INSERT INTO test_wifi.members (firstname, lastname, email, type, phonenumber, birthday, reg_date, password, salt) ' .
//            'VALUES(:firstname, :lastname, :email, :type, :phonenumber, :birthday, :reg_date, SHA2(CONCAT(:password, ' . $uniqid . '), 0)');
//        INSERT INTO test_wifi.members (firstname, lastname, email, type, phonenumber, birthday, reg_date, password, salt) VALUES('john', 'cooper', 'abc@abcd.com', 'F', '1300-543-245', '05-03-1980', '25-05-2016','574484a424a6e', SHA2(CONCAT('kfc1!', '574484a424a6e'), 0));

        // insert. salt and encrypt password
        $stmt = $pdo->prepare('INSERT INTO test_wifi.members (firstname, lastname, email, type, phonenumber, birthday, reg_date, salt, password) '.
            'VALUES(:firstname, :lastname, :email, :type, :phonenumber, :birthday, :reg_date, :uniqid, SHA2(CONCAT(:password, :uniqid), 0))');

        $stmt->bindParam(':firstname', $firstname, PDO::PARAM_STR);
        $stmt->bindParam(':lastname', $lastname, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':type', $type, PDO::PARAM_STR);
        $stmt->bindParam(':phonenumber', $phoneNum, PDO::PARAM_STR);
        $stmt->bindParam(':birthday', $birthDay, PDO::PARAM_STR);
        $stmt->bindParam(':reg_date', $today, PDO::PARAM_STR);
        $stmt->bindParam(':password', $password, PDO::PARAM_STR);
        $stmt->bindParam(':uniqid', $uniqid, PDO::PARAM_STR);

        $stmt->execute();

        // success
        echo "<script>alert('Registered successfully!!\\r\\nIt will be moved to main page automatically');</script>";
        echo "<script>location.href='http://{$_SERVER['HTTP_HOST']}/Team94-SII/test_kihoon/test_wifi/index.html'</script>";

    }

    // fail to insert
    catch (Exception $e) {
        echo "errorrrrrrrrrrrrrrrrrr<br>";
        echo $e->getMessage();
//        echo "history.back();";
    }

}
?>
