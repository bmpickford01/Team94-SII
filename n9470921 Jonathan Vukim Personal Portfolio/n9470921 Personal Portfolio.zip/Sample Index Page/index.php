<html>
<head>
	<link rel = "stylesheet" type = "text/css" href = "style.css"/>
</head>
<body>
	<div id = "wrapper">
		<div id = "header">
		</div>
		<div id = "login">
			<a href = "index.php">Login here</a>
		</div>
		<div id = "menu">
			<a href = "index.php">placeholder</a>
			<a href = "index.php">placeholder</a>
			<a href = "index.php">placeholder</a>
			<a href = "index.php">placeholder</a>
		</div>
		<div id = "content">
			content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder content placeholder 
		</div>
		<div id = "footer">
			meme us on +61404 040 404
		</div>
	</div>
</body>
</html>